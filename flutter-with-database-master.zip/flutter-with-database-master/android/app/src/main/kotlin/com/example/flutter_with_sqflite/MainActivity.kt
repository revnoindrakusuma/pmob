package com.example.flutter_with_sqflite

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
